﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json;
using Rps.Models;

namespace Rps.Pages
{
    public partial class ViewScore : Page
    {
        private Frame _frame;
        private string _jsonFilePath = "gameResults.json";

        public ViewScore(Frame frame)
        {
            InitializeComponent();
            _frame = frame;
            LoadScores();
        }

        private void LoadScores()
        {
            if (File.Exists(_jsonFilePath))
            {
                string json = File.ReadAllText(_jsonFilePath);
                var result = JsonConvert.DeserializeObject<GameResult>(json);
                if (result != null)
                {
                    WinsText.Text = result.TotalWins.ToString();
                    LossesText.Text = result.TotalLosses.ToString();
                }
            }
            else
            {
                WinsText.Text = "0";
                LossesText.Text = "0";
            }
        }

        private void ResetScores_Click(object sender, RoutedEventArgs e)
        {
            var result = new GameResult(0, 0);
            File.WriteAllText(_jsonFilePath, JsonConvert.SerializeObject(result, Formatting.Indented));
            WinsText.Text = "0";
            LossesText.Text = "0";
        }

        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new HomePage(_frame)); 
        }
    }
}

