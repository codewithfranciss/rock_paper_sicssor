﻿using Newtonsoft.Json;
using System.IO;
using System.Windows;
using Rps.Models;
using System.Windows.Controls;
using System.Windows.Media;

namespace Rps.Pages
{
    public partial class GamePage : Page
    {
        private Frame _frame;
        private readonly Random _random = new Random();
        private int _rounds;
        private int _userScore = 0;
        private int _computerScore = 0;
        private int _currentRound = 1;
        private string _jsonFilePath = "gameResults.json";

        public GamePage(Frame frame, int rounds)
        {
            InitializeComponent();
            _frame = frame;
            _rounds = rounds;
            UpdateRoundText();
        }
        private void Rock_Click(object sender, RoutedEventArgs e)
        {
            SetSelections("Rock");
        }

        private void Paper_Click(object sender, RoutedEventArgs e)
        {
            SetSelections("Paper");
        }

        private void Scissors_Click(object sender, RoutedEventArgs e)
        {
            SetSelections("Scissors");
        }
        private void SetSelections(string userChoice)
        {
            SelectionText.Text = $"You selected {userChoice}";

            string[] options = { "Rock", "Paper", "Scissors" };
            string computerChoice = options[_random.Next(options.Length)];

            ComputerSelectionText.Text = $"Computer selected {computerChoice}";

            string result;

            // Determine the result of the game
            if (userChoice == computerChoice)
            {
                result = "It's a draw!";
                Result.Foreground = new SolidColorBrush(Colors.Orange);
            }
            else if (
                (userChoice == "Rock" && computerChoice == "Scissors") ||
                (userChoice == "Paper" && computerChoice == "Rock") ||
                (userChoice == "Scissors" && computerChoice == "Paper")
            )
            {
                result = "You win!";
                _userScore++;
                Result.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 128, 0));
            }
            else
            {
                result = "Computer wins!";
                _computerScore++;
                Result.Foreground = new SolidColorBrush(Colors.Red);
            }

            // Update the result text and scores
            ResultText.Text = result;
            UserScoreText.Text = _userScore.ToString();  
            ComputerScoreText.Text = _computerScore.ToString();  
            _currentRound++;
            UpdateRoundText();
            

            if (_currentRound > _rounds)
            {
               
                SaveGameResults();
                MessageBox.Show($"Saved: Wins = {_userScore}, Losses = {_computerScore}");
                NavigateToHomePage();
                
            }
        }

        private void UpdateRoundText()
        {
            RoundsText.Text = $"Round {_currentRound} of {_rounds}";
        }
        private void NavigateToHomePage()
        {
            _frame.Navigate(new HomePage(_frame)); 
        }

        private void SaveGameResults()
        {
            int userWins = _userScore;
            int userLosses = _computerScore;
            GameResult gameResult = new GameResult(userWins, userLosses);

            if (File.Exists(_jsonFilePath))
            {
                string json = File.ReadAllText(_jsonFilePath);
                var existingResults = JsonConvert.DeserializeObject<GameResult>(json);

                if (existingResults != null)
                {
                    existingResults.TotalWins += gameResult.TotalWins;
                    existingResults.TotalLosses += gameResult.TotalLosses;
                }
                else
                {
                    existingResults = gameResult;
                }

                File.WriteAllText(_jsonFilePath, JsonConvert.SerializeObject(existingResults, Formatting.Indented));
            }
            else
            {
                File.WriteAllText(_jsonFilePath, JsonConvert.SerializeObject(gameResult, Formatting.Indented));
            }
        }


    }
}
