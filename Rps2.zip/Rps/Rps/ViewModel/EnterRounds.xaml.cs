﻿using System.Windows;
using System.Windows.Controls;

namespace Rps.Pages
{
    public partial class EnterRounds : Page
    {
        private Frame _frame;

        public EnterRounds(Frame frame)
        {
            InitializeComponent();
            _frame = frame;
        }

        private void EnterGame_Click(object sender, RoutedEventArgs e)
        {
            string input = RoundsInput.Text;

            if (int.TryParse(input, out int rounds))
            {
                if (rounds >= 1 && rounds <= 10)
                {
                    _frame.Navigate(new GamePage(_frame, rounds));
                }
                else
                {
                    MessageBox.Show("Please enter a number between 1 and 10.");
                }
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a number.");
            }
        }
    }
}
