﻿using System.Windows.Controls;
using System.Windows;

namespace Rps.Pages
{
    public partial class HomePage : Page
    {
        private Frame _frame;

        public HomePage(Frame frame)
        {
            InitializeComponent();
            _frame = frame;
        }

        private void GoToGame_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new EnterRounds(_frame));
        }
        private void GotoScore_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new ViewScore(_frame));
        }

    }
}
