﻿namespace Rps.Models;
public class GameResult
{
    public int TotalWins { get; set; }
    public int TotalLosses { get; set; }

    public GameResult(int totalWins, int totalLosses)
    {
        TotalWins = totalWins;
        TotalLosses = totalLosses;
    }
}
